/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/lab/Desktop/UCiSW-Lab-6-main/lab6/zamek.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_4110184194_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 1792U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4856);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(52, ng0);
    t3 = (t0 + 1672U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 2632U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 4968);
    t4 = (t1 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t2;
    xsi_driver_first_trans_fast(t1);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(53, ng0);
    t3 = (t0 + 4968);
    t7 = (t3 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)0;
    xsi_driver_first_trans_fast(t3);
    goto LAB6;

}

static void work_a_4110184194_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    static char *nl0[] = {&&LAB9, &&LAB10, &&LAB11, &&LAB12, &&LAB13};

LAB0:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 5032);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB5;

LAB6:    t3 = (unsigned char)0;

LAB7:    if (t3 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4872);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 2472U);
    t5 = *((char **)t1);
    t12 = *((unsigned char *)t5);
    t1 = (char *)((nl0) + t12);
    goto **((char **)t1);

LAB5:    t1 = (t0 + 1352U);
    t4 = *((char **)t1);
    t10 = *((unsigned char *)t4);
    t11 = (t10 == (unsigned char)2);
    t3 = t11;
    goto LAB7;

LAB8:    goto LAB3;

LAB9:    xsi_set_current_line(68, ng0);
    t6 = (t0 + 7767);
    t13 = (4U != 4U);
    if (t13 == 1)
        goto LAB14;

LAB15:    t14 = (t0 + 5096);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t6, 4U);
    xsi_driver_first_trans_delta(t14, 60U, 4U, 0LL);
    xsi_set_current_line(69, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7771);
    t3 = 1;
    if (8U == 8U)
        goto LAB19;

LAB20:    t3 = 0;

LAB21:    if (t3 != 0)
        goto LAB16;

LAB18:
LAB17:    goto LAB8;

LAB10:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 7779);
    t3 = (4U != 4U);
    if (t3 == 1)
        goto LAB25;

LAB26:    t4 = (t0 + 5096);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t14 = *((char **)t7);
    memcpy(t14, t1, 4U);
    xsi_driver_first_trans_delta(t4, 60U, 4U, 0LL);
    xsi_set_current_line(76, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7783);
    t3 = 1;
    if (8U == 8U)
        goto LAB30;

LAB31:    t3 = 0;

LAB32:    if (t3 != 0)
        goto LAB27;

LAB29:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7791);
    t3 = 1;
    if (8U == 8U)
        goto LAB38;

LAB39:    t3 = 0;

LAB40:    if (t3 != 0)
        goto LAB36;

LAB37:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 5032);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB28:    goto LAB8;

LAB11:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 7799);
    t3 = (4U != 4U);
    if (t3 == 1)
        goto LAB44;

LAB45:    t4 = (t0 + 5096);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t14 = *((char **)t7);
    memcpy(t14, t1, 4U);
    xsi_driver_first_trans_delta(t4, 60U, 4U, 0LL);
    xsi_set_current_line(87, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7803);
    t3 = 1;
    if (8U == 8U)
        goto LAB49;

LAB50:    t3 = 0;

LAB51:    if (t3 != 0)
        goto LAB46;

LAB48:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7811);
    t3 = 1;
    if (8U == 8U)
        goto LAB57;

LAB58:    t3 = 0;

LAB59:    if (t3 != 0)
        goto LAB55;

LAB56:    xsi_set_current_line(92, ng0);
    t1 = (t0 + 5032);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB47:    goto LAB8;

LAB12:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 7819);
    t3 = (4U != 4U);
    if (t3 == 1)
        goto LAB63;

LAB64:    t4 = (t0 + 5096);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t14 = *((char **)t7);
    memcpy(t14, t1, 4U);
    xsi_driver_first_trans_delta(t4, 60U, 4U, 0LL);
    xsi_set_current_line(98, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7823);
    t3 = 1;
    if (8U == 8U)
        goto LAB68;

LAB69:    t3 = 0;

LAB70:    if (t3 != 0)
        goto LAB65;

LAB67:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7831);
    t3 = 1;
    if (8U == 8U)
        goto LAB76;

LAB77:    t3 = 0;

LAB78:    if (t3 != 0)
        goto LAB74;

LAB75:    xsi_set_current_line(103, ng0);
    t1 = (t0 + 5032);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB66:    goto LAB8;

LAB13:    xsi_set_current_line(108, ng0);
    t1 = (t0 + 7839);
    t3 = (4U != 4U);
    if (t3 == 1)
        goto LAB82;

LAB83:    t4 = (t0 + 5096);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t14 = *((char **)t7);
    memcpy(t14, t1, 4U);
    xsi_driver_first_trans_delta(t4, 60U, 4U, 0LL);
    xsi_set_current_line(109, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB84;

LAB86:
LAB85:    goto LAB8;

LAB14:    xsi_size_not_matching(4U, 4U, 0);
    goto LAB15;

LAB16:    xsi_set_current_line(70, ng0);
    t7 = (t0 + 5032);
    t14 = (t7 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)1;
    xsi_driver_first_trans_fast(t7);
    goto LAB17;

LAB19:    t19 = 0;

LAB22:    if (t19 < 8U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t5 = (t2 + t19);
    t6 = (t1 + t19);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB20;

LAB24:    t19 = (t19 + 1);
    goto LAB22;

LAB25:    xsi_size_not_matching(4U, 4U, 0);
    goto LAB26;

LAB27:    xsi_set_current_line(77, ng0);
    t7 = (t0 + 5032);
    t14 = (t7 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)2;
    xsi_driver_first_trans_fast(t7);
    goto LAB28;

LAB30:    t19 = 0;

LAB33:    if (t19 < 8U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t5 = (t2 + t19);
    t6 = (t1 + t19);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB31;

LAB35:    t19 = (t19 + 1);
    goto LAB33;

LAB36:    xsi_set_current_line(79, ng0);
    t7 = (t0 + 5032);
    t14 = (t7 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)1;
    xsi_driver_first_trans_fast(t7);
    goto LAB28;

LAB38:    t19 = 0;

LAB41:    if (t19 < 8U)
        goto LAB42;
    else
        goto LAB40;

LAB42:    t5 = (t2 + t19);
    t6 = (t1 + t19);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB39;

LAB43:    t19 = (t19 + 1);
    goto LAB41;

LAB44:    xsi_size_not_matching(4U, 4U, 0);
    goto LAB45;

LAB46:    xsi_set_current_line(88, ng0);
    t7 = (t0 + 5032);
    t14 = (t7 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB47;

LAB49:    t19 = 0;

LAB52:    if (t19 < 8U)
        goto LAB53;
    else
        goto LAB51;

LAB53:    t5 = (t2 + t19);
    t6 = (t1 + t19);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB50;

LAB54:    t19 = (t19 + 1);
    goto LAB52;

LAB55:    xsi_set_current_line(90, ng0);
    t7 = (t0 + 5032);
    t14 = (t7 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)1;
    xsi_driver_first_trans_fast(t7);
    goto LAB47;

LAB57:    t19 = 0;

LAB60:    if (t19 < 8U)
        goto LAB61;
    else
        goto LAB59;

LAB61:    t5 = (t2 + t19);
    t6 = (t1 + t19);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB58;

LAB62:    t19 = (t19 + 1);
    goto LAB60;

LAB63:    xsi_size_not_matching(4U, 4U, 0);
    goto LAB64;

LAB65:    xsi_set_current_line(99, ng0);
    t7 = (t0 + 5032);
    t14 = (t7 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)4;
    xsi_driver_first_trans_fast(t7);
    goto LAB66;

LAB68:    t19 = 0;

LAB71:    if (t19 < 8U)
        goto LAB72;
    else
        goto LAB70;

LAB72:    t5 = (t2 + t19);
    t6 = (t1 + t19);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB69;

LAB73:    t19 = (t19 + 1);
    goto LAB71;

LAB74:    xsi_set_current_line(101, ng0);
    t7 = (t0 + 5032);
    t14 = (t7 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)1;
    xsi_driver_first_trans_fast(t7);
    goto LAB66;

LAB76:    t19 = 0;

LAB79:    if (t19 < 8U)
        goto LAB80;
    else
        goto LAB78;

LAB80:    t5 = (t2 + t19);
    t6 = (t1 + t19);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB77;

LAB81:    t19 = (t19 + 1);
    goto LAB79;

LAB82:    xsi_size_not_matching(4U, 4U, 0);
    goto LAB83;

LAB84:    xsi_set_current_line(110, ng0);
    t1 = (t0 + 5032);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB85;

}

static void work_a_4110184194_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(116, ng0);
    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)4);
    if (t4 != 0)
        goto LAB3;

LAB4:
LAB5:    t9 = (t0 + 5160);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);

LAB2:    t14 = (t0 + 4888);
    *((int *)t14) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 5160);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_4110184194_3212880686_p_3(char *t0)
{
    char *t1;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(117, ng0);

LAB3:    t1 = (t0 + 7843);
    t3 = (t0 + 5224);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 16U);
    xsi_driver_first_trans_fast_port(t3);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_4110184194_3212880686_init()
{
	static char *pe[] = {(void *)work_a_4110184194_3212880686_p_0,(void *)work_a_4110184194_3212880686_p_1,(void *)work_a_4110184194_3212880686_p_2,(void *)work_a_4110184194_3212880686_p_3};
	xsi_register_didat("work_a_4110184194_3212880686", "isim/zamek_test_isim_beh.exe.sim/work/a_4110184194_3212880686.didat");
	xsi_register_executes(pe);
}
