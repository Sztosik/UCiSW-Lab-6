# Simple Pong Game

The project was developed as part of the Digital Circuits and Embedded Systems course.

It includes the implementation of a simple Pong game in the `VHDL` language.
The project is divided into two modules:

- `vga`: Game display control.
- `game`: Game logic.
